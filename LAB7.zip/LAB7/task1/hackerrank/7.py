if __name__ == '__main__':
    n = int(input())
    somestring=''
    for i in range (1,n+1):
        somestring+=str(i)
    print(somestring)