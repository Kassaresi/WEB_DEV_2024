def first_two(str):
  return str[:2]