def make_tags(tag, word):
  return '<%s>%s</%s>' % (tag,word,tag)