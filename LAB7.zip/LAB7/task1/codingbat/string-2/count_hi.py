def count_hi(str:str):
  return str.count("hi")