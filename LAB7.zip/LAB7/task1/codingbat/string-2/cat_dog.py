def cat_dog(str:str):
  return str.count("cat")==str.count("dog")