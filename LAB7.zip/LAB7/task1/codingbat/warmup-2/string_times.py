def string_times(str, n):
  ans=''
  for i in range(n):
    ans+=str
  return ans
