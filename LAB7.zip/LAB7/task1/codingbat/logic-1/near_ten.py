def near_ten(num):
    remainder = num % 10
    
    return remainder <= 2 or remainder >= 8