def sorta_sum(a, b):
    total = a + b
    
    if 10 <= total <= 19:
        return 20
    else:
        return total
