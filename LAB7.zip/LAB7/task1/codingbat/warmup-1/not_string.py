def not_string(str:str):
  noth='not '
  if(str.find("not")==0):
    return str
  return noth+str