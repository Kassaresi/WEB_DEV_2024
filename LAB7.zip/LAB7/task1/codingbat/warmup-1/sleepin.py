def sleep_in(weekday, vacation):
  if(weekday and not vacation ):
    return False
  return True