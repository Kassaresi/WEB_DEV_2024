
def diff21(n):
  if(21>n):
    return 21-n
  else:
    return (n-21)*2