def max_end3(nums):
    return [max(nums[0], nums[-1])] * 3