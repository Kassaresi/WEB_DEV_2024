def reverse3(nums:list):
    nums.reverse()
    return nums

  