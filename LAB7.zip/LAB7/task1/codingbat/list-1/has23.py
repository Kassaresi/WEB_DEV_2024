def has23(nums:list):
    return nums.count(2)!=0 or nums.count(3)!=0
  