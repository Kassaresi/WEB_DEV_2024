def sum3(nums:list):
  return sum(nums)
