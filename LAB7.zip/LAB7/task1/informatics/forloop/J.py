summ=0
for i in range (100):
    summ+=int(input())
print(summ)