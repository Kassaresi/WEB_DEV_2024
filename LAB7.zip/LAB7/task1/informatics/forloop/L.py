a=input()

b=int(a,2)
print(b)