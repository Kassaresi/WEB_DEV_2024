x=(input())
conut=0

for i in range(0,len(x)):
    conut+=int(x[i])
print(conut)