x=(input())
d=(input())
conut=0

for i in range(0,len(x)):
    if(x[i]==d):
        conut+=1
print(conut)