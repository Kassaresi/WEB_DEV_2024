summ=0
number=int(input())
for i in range (number):
    summ+=int(input())
print(summ)