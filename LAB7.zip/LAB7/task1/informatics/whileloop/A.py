a=int(input())
b=1
while(b**2<=a):
    print(b**2)
    b+=1