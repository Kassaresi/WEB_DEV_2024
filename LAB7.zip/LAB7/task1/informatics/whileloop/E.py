a=int(input())
k=0
while(2**k<a):
    k+=1
print(k)