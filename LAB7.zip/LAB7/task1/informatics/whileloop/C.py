a=int(input())
i=0
while(2**i<=a):
    print(2**i,end=" ")
    i+=1