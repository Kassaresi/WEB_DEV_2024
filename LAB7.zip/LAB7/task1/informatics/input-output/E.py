
a=int(input())
b=int(input())
print((b*a)%109)
