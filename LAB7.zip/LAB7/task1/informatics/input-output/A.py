import math

a=int(input())
b=int(input())
print(math.sqrt(a**2+b**2))