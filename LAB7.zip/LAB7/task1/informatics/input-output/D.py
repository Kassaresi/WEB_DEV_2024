
a=int(input())
b=int(input())
print(int(b%a))
