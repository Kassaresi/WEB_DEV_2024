import math

a=int(input())

print("The next number for the number %d is %d." % (a,a+1))
print("The previous number for the number %d is %d." % (a,a-1))
